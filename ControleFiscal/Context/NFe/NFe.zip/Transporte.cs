﻿namespace ControleFiscal.Context.NFe
{
    using System.ComponentModel;

    public class Transporte
    {
        [Description("Modalidade do frete")]
        public string ModFrete { get; set; }

        [Description("Informações do transportador")]
        public Transportador Transporta { get; set; }

        [Description("Informações do veículo de transporte")]
        public Veiculo VeicTransp { get; set; }

        [Description("Informações de reboques do veículo")]
        public List<Veiculo> Reboque { get; set; }

        [Description("Identificação da balsa")]
        public string Balsa { get; set; }

        [Description("Informações dos volumes transportados")]
        public List<Volume> Vol { get; set; }
    }

    public class Transportador
    {
        [Description("CNPJ do transportador")]
        public string CNPJ { get; set; }

        [Description("CPF do transportador")]
        public string CPF { get; set; }

        [Description("Nome ou razão social")]
        public string XNome { get; set; }

        [Description("Inscrição Estadual do transportador")]
        public string IE { get; set; }

        [Description("Endereço completo")]
        public string XEnder { get; set; }

        [Description("Nome do município")]
        public string XMun { get; set; }

        [Description("UF do município")]
        public string UF { get; set; }

        // Adicione outros campos conforme necessário
    }

    public class Veiculo
    {
        [Description("Placa do veículo")]
        public string Placa { get; set; }

        [Description("UF da placa do veículo")]
        public string UF { get; set; }

        [Description("Registro Nacional de Transportador de Carga (ANTT)")]
        public string RNTC { get; set; }
    }

    public class Volume
    {
        [Description("Quantidade de volumes transportados")]
        public int QVol { get; set; }

        [Description("Espécie dos volumes transportados")]
        public string Esp { get; set; }

        [Description("Marca dos volumes transportados")]
        public string Marca { get; set; }

        [Description("Numeração dos volumes transportados")]
        public string NVol { get; set; }

        [Description("Peso líquido (total)")]
        public decimal PesoL { get; set; }

        [Description("Peso bruto (total)")]
        public decimal PesoB { get; set; }

    }

}
